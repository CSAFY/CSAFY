package csafy.userservice.dto.auth;

import lombok.Data;

@Data
public class AuthReqModel {
    private String id;
    private String password;
}
