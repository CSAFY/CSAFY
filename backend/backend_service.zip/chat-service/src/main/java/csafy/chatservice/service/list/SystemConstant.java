package csafy.chatservice.service.list;

public class SystemConstant {

    public static final Integer MESSAGE_MAX_LENGTH = 5;

}
